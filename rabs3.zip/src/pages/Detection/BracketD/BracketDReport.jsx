import { Box, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material'
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';

const BACKEND_API = import.meta.env.VITE_BACKEND_API;


const BracketDReport = ({addedItem}) => {
    const {token}= useSelector((state) => state.auth);
    const [isShowImg, setIsShowImg] = useState(false);
    const [selectedImg, setSelectedImg] = useState('');

    const [reports, setReports]= useState([]);
    console.log(reports);

    useEffect(() => {
  async function fetchData() {
    try {
      const response = await axios.get(`${BACKEND_API}/images-data-classificaton`, {
        headers: {
          Authorization: `Bearer ${token}`,
        }
      });

      console.log(response.data);
      setReports(response.data.images);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  fetchData();
}, [addedItem]);
  return (
    <Box position={'relative'}>

      {isShowImg && 
      <Box onClick={()=> {setIsShowImg(false)}} bgcolor={'rgba(24, 24, 24, 0.77)'} sx={{overflowY: 'auto'}} position={'fixed'} height={'100%'} width={'100%'} zIndex={'77'} top={0} left={'0'} display={'flex'} alignItems={'center'} justifyContent={'center'}>
          <img onClick={(e)=> {e.stopPropagation()}} style={{width: '70%', marginTop: '1rem', cursor: 'pointer', boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px'}} src={selectedImg} alt="" />
          {/* <Button sx={{position: 'absolute', top: '1rem', right: '1rem'}} onClick={()=> setIsShowImg(false)}>Delete</Button> */}
      
         </Box>}
        <Typography fontSize={'1.4rem'} borderBottom={'1px solid black'} width={'9rem'} m={'2rem 1rem'}>Report:-</Typography>

        <Paper >
          <TableContainer>
            <Table aria-label="simple table" border={1} >
              <TableHead sx={{ bgcolor: "grey", border: "1px solid black" }}>
                
                <TableRow sx={{bgcolor: 'rgb(164, 182, 211)', boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px'}}>
                  <TableCell sx={{ fontSize: "1.2rem" }}>Sr No</TableCell>
                  <TableCell align="center" sx={{ fontSize: "1.2rem" }}>
                    Date
                  </TableCell>
                  <TableCell align="center" sx={{ fontSize: "1.2rem" }}>
                    Time
                  </TableCell>
                  <TableCell align="center" sx={{ fontSize: "1.2rem" }}>
                    Original Image
                  </TableCell>
                  <TableCell align="center" sx={{ fontSize: "1.2rem" }}>
                    Process Image
                  </TableCell>
                  {/* <TableCell align="center" sx={{fontSize: '1.2rem'}}>Count</TableCell> */}
                  
                </TableRow>
              </TableHead>

              <TableBody>
              {/* {isLoading && (
                  <TableRow>
                    <TableCell colSpan={12} align="center">
                      <Typography>Loading...</Typography>
                    </TableCell>
                  </TableRow>
                )} */}
                {
                    reports.length> 0 && reports.map((report, index)=>(
                        <TableRow key={index} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                            <TableCell component="th" scope="row">
                            {index + 1}
                            </TableCell>
                            <TableCell align="center">{report.date}</TableCell>
                            <TableCell align="center">{report.time}</TableCell>
                            <TableCell align="center">
                            <img src={report.original_url} alt={`Original ${index}`} style={{ width: '100px', height: '100px' }} />
                            </TableCell>
                            <TableCell align="center">
                            <img src={report.processed_url} onClick={()=> setSelectedImg(report.processed_url)} alt={`Processed ${index}`} style={{ width: '100px', height: '100px' }} />
                            </TableCell>
                        </TableRow>
                    ))
                }
               
                
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
    </Box>
  )
}

export default BracketDReport