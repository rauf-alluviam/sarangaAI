const colors = {
    primary: "rgb(241, 92, 109)", // pink
    secondary: "#2ecc71", // Green
    background: "#f4f4f4", // Light Grey
    sidebar: "#2c3e50", // Dark Grey
    navbar: "#e74c3c", // Red
    textPrimary: "#ffffff", // White
    textSecondary: "#333333", // Dark Text
  };
  
  export default colors;