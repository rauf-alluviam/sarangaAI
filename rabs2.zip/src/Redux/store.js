import { applyMiddleware, combineReducers, legacy_createStore } from "redux";
import { thunk } from "redux-thunk";
import authReducer from "./Reducers/authReducer";
import { cameraReducer } from "./Reducers/cameraReducers";

const rootReducer= combineReducers({
    auth: authReducer,
    cameras: cameraReducer
})

const store= legacy_createStore(rootReducer, applyMiddleware(thunk));
export default store;